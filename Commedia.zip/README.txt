COMMEDIA: the download

Open Commedia.html in your browser (double-click it). It is the whole game in one file: all three chapters, the rules (the Rules button at the top), the cards and the dice.
It needs no internet, no account and no installation.

Computers (Mac, Windows, Linux): double-click Commedia.html.
Android: open the file with Chrome from the Files app. It should work the same; that has not been tried.
iPhone and iPad cannot open a loose file: use the web address instead (see below).

A run you leave in the middle is saved in the browser you opened the file with, on that device. Clearing the browser's data, or opening the file in another browser, starts fresh.

On a phone or tablet: open https://1980finbar.github.io/Commedia/ once, then Share, Add to Home Screen (iPhone, iPad) or the menu, Install app (Android). From then on it plays with no connection.

Licence: Commedia is free to play for personal use. Copyright (c) 2026 Finbar Bruins. All rights reserved. See LICENSE.txt.
The two fonts are under the SIL Open Font License 1.1 (FONT-LICENSES.txt).
